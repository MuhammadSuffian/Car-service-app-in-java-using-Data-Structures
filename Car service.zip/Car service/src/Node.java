/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author stu
 */
public class Node {
    String TokenID,appointement,Model,Registeration,carcategory;
    Node next;
    Node previous;

    public Node(String TokenID, String appointement, String Model, String Registeration, String carcategory) {
        this.TokenID = TokenID;
        this.appointement = appointement;
        this.Model = Model;
        this.Registeration = Registeration;
        this.carcategory = carcategory;
        next=null;
        previous=null;
    }
    
    
    
}
