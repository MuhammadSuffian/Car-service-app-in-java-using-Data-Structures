
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author stu
 */
public class Stack extends Historyofappointemenets {
    Node head;
    Node tail;
    String Gmail,Pass,Fname,CNIC,Contact;
     Stack(String Gmail,String Pass,String Fname,String CNIC, String Contact) {
        head = null;
        tail=null;
        this.Gmail=Gmail;
        this.Pass=Pass;
        this.Fname=Fname;
        this.CNIC=CNIC;
        this.Contact=Contact;
    }
      public void displayclcokwise(){
        Node temp=head;
         System.out.println(" \nDisplaying forward(Clock wise)");
         if(temp!=null){
             do{
             System.out.print(temp.TokenID+" ");
            temp=temp.next;
        }while(temp.next!=null);
        }
        else{
         System.out.println("Sorry linked list empty can't Dsipaly");
         }
         System.out.println(" ");
    }
     
      
      public void displaycounterclcokwise(){
        Node temp=tail;
        System.out.println("\n Displaying Backward(counter clock wise)");
         if(temp!=null){
            do{
                 System.out.print(temp.TokenID+" ");
            temp=temp.previous;
        }while(temp!=null);
        }
        else{
         System.out.println("Sorry linked list empty can't Dsipaly");
         }
         System.out.println(" ");
    }
      
      public void push(String TokenID,String appointement,String Model,String Registeration,String carcategory){
          Node n=new Node(TokenID,appointement,Model,Registeration,carcategory);
          if(head==null){
              head=n;
              tail=n;
          }
          else {
              tail.next=n;
              n.previous=tail;
              tail=n;
          }
      }
      public ArrayList<String> pop(){
          ArrayList<String> arr=new ArrayList<String>();
          Node temp=tail;
          if(temp!=null){
              while(temp!=null){
              System.out.println("POP");
             arr.add(temp.TokenID);
             arr.add(temp.appointement);
             arr.add(temp.Model);
             arr.add(temp.Registeration);
             arr.add(temp.carcategory);
              temp=temp.previous;
              tail=temp;
              }
              return arr;
          }
          else{
                System.out.println("Stack is empty"); 
                return null;
          }
      }
    
}

