
import java.util.ArrayList;
import javax.swing.JOptionPane;


public class Queue {
    Node head;
    Node tail;
    Queue(){
        head=null;
        tail=null;
    }
     public void EnQueue(String TokenID,String appointement,String Model,String Registeration,String carcategory){
          Node n=new Node(TokenID,appointement,Model,Registeration,carcategory);
          if(head==null){
              head=n;
              tail=n;
          }
          else {
              tail.next=n;
              n.previous=tail;
              tail=n;
          }
           System.out.println("\nInserting\nToken ID: "+TokenID+"  Appointement : "+appointement+"  Model: "+Model+"  Registeration:  "+Registeration+"  Carcategory : "+carcategory);
      }
     public void dispaly(){
          Node temp=head;
          while(temp!=null){
           System.out.println("\nToken ID: "+temp.TokenID+"  Appointement : "+temp.appointement+"  Model: "+temp.Model+"  Registeration:  "+temp.Registeration+"  Carcategory : "+temp.carcategory);
           temp=temp.next;   
          }
          
     }
     
//      public ArrayList<String> Dqueue(){
//          ArrayList<String> arr=new ArrayList<String>();
//          Node temp=head;
//          if(temp!=null){
//              while(temp!=null){
//              System.out.println("POP");
//             arr.add(temp.TokenID);
//             arr.add(temp.appointement);
//             arr.add(temp.Model);
//             arr.add(temp.Registeration);
//             arr.add(temp.carcategory);
//             System.out.println("\nToken ID: "+temp.TokenID+"  Appointement : "+temp.appointement+"  Model: "+temp.Model+"  Registeration:  "+temp.Registeration+"  Carcategory : "+temp.carcategory);
//             temp=temp.next;
//             head=temp;
//             
//              }
//              return arr;
//          }
//          else{
//                System.out.println("Stack is empty"); 
//                return null;
//          }
//      }
     
        public ArrayList<String> Dqueuev2(){
          ArrayList<String> arr=new ArrayList<String>();
          Node temp=head;
          if(temp!=null){
              if(temp.carcategory==null){
                   System.out.println("Stack is empty"); 
                   JOptionPane.showMessageDialog(null,"Sorry there are appointemenets no more.");
                return null;
              }
              
             System.out.println("POP");
             arr.add(temp.TokenID);
             arr.add(temp.appointement);
             arr.add(temp.Model);
             arr.add(temp.Registeration);
             arr.add(temp.carcategory);
             System.out.println("\nToken ID: "+temp.TokenID+"  Appointement : "+temp.appointement+"  Model: "+temp.Model+"  Registeration:  "+temp.Registeration+"  Carcategory : "+temp.carcategory);
             temp=temp.next;
             head=temp;
         
              return arr;
          
          }
          else{
                System.out.println("Stack is empty"); 
                JOptionPane.showMessageDialog(null,"Sorry there are appointemenets no more.");
                return null;
          }
      }
           public ArrayList<String> outqueue(){
          ArrayList<String> arr=new ArrayList<String>();
          Node temp=head;
          if(temp!=null){
              while(temp!=null){
             System.out.println("POP");
             arr.add(temp.TokenID);
             arr.add(temp.appointement);
             arr.add(temp.Model);
             arr.add(temp.Registeration);
             arr.add(temp.carcategory);
             System.out.println("\nToken ID: "+temp.TokenID+"  Appointement : "+temp.appointement+"  Model: "+temp.Model+"  Registeration:  "+temp.Registeration+"  Carcategory : "+temp.carcategory);
             temp=temp.next;
             
              }
              return arr;
          }
          else{
                System.out.println("Stack is empty"); 
                return null;
          }
      }
            public void Delete(String key){
          Node temp=head;
          if(temp.TokenID==key){
              head=temp.next;
              head.next.previous=head;
          }
          else if(tail.TokenID==key){ 
              temp=tail.previous;
              tail.previous=null;
              tail=temp;
              
          }
          else if(head==tail){
          }
          else{
              temp=head;
              while(temp.next!=null){
              if(temp.next.TokenID==key){
               //    System.out.println(temp.next.data+"k");
                  temp.next=temp.next.next;    
                  temp.next.next.previous=temp;
                  return;
                          
              }
              temp=temp.next;
          }
              
          }
          
      }
    
}
